import tkinter as tk
from tkinter import messagebox, simpledialog, ttk
from controller import controller
from dbmodel import SecurityData
from view import display_portfolio_graph  # למעלה בקובץ gui.py


class PortfolioApp:
    def __init__(self, master):
        self.master = master
        risk_level = simpledialog.askstring("Risk Level", "Enter your risk level (Low / Medium / High):", parent=master)
        self.controller = controller(risk_level=risk_level.capitalize() if risk_level else "Medium")
        master.title("Investment Portfolio Manager")
        master.geometry("600x400")

        self.create_main_menu()

    def create_main_menu(self):
        tk.Label(self.master, text="Investment Portfolio Manager", font=("Arial", 16)).pack(pady=10)

        tk.Button(self.master, text="Buy Securities", command=self.buy_screen, width=30, height=2).pack(pady=5)
        tk.Button(self.master, text="Sell Securities", command=self.sell_screen, width=30, height=2).pack(pady=5)
        tk.Button(self.master, text="Show Portfolio", command=self.show_portfolio, width=30, height=2).pack(pady=5)
        tk.Button(self.master, text="Show Portfolio Graph", command=self.show_graph, width=30, height=2).pack(pady=5)
        tk.Button(self.master, text="Exit", command=self.master.quit, width=30, height=2).pack(pady=20)

    def buy_screen(self):
        buy_window = tk.Toplevel(self.master)
        buy_window.title("Buy Securities")
        buy_window.geometry("700x400")

        securities = self.controller.get_available_securities()

        tree = ttk.Treeview(buy_window, columns=('Name', 'Type', 'Subtype', 'Sector', 'Variance', 'Price'), show='headings')
        tree.heading('Name', text='Name')
        tree.heading('Type', text='Type')
        tree.heading('Subtype', text='Subtype')
        tree.heading('Sector', text='Sector')
        tree.heading('Variance', text='Variance')
        tree.heading('Price', text='Price')
        tree.pack(expand=True, fill='both')

        for sec in securities:
            tree.insert('', 'end', values=(sec.name, sec.security_type, sec.subtype, sec.sector, sec.variance, sec.basevalue))

        def confirm_buy():
            selected_item = tree.selection()
            if not selected_item:
                messagebox.showerror("Error", "Please select a security to buy.")
                return
            sec_values = tree.item(selected_item[0], 'values')
            sec = next(s for s in securities if s.name == sec_values[0])

            try:
                amount = int(simpledialog.askstring("Amount", "Enter amount to buy:"))
            except (TypeError, ValueError):
                messagebox.showerror("Error", "Invalid amount.")
                return

            success, msg = self.controller.buy(
                name=sec.name, sector=sec.sector, variance=sec.variance,
                security_type=sec.security_type, subtype=sec.subtype,
                amount=amount, basevalue=sec.basevalue
            )
            messagebox.showinfo("Buy Result", msg)

        tk.Button(buy_window, text="Buy Selected Security", command=confirm_buy).pack(pady=10)

    def sell_screen(self):
        sell_window = tk.Toplevel(self.master)
        sell_window.title("Sell Securities")
        sell_window.geometry("700x400")

        portfolio = self.controller.get_portfolio_data()

        tree = ttk.Treeview(sell_window, columns=('Name', 'Amount', 'Basevalue', 'Sector', 'Subtype'), show='headings')
        tree.heading('Name', text='Name')
        tree.heading('Amount', text='Amount')
        tree.heading('Basevalue', text='Base Value')
        tree.heading('Sector', text='Sector')
        tree.heading('Subtype', text='Subtype')
        tree.pack(expand=True, fill='both')

        for sec in portfolio:
            tree.insert('', 'end', values=(sec.name, sec.ammont, sec.basevalue, sec.sector, sec.subtype))

        def confirm_sell():
            selected_item = tree.selection()
            if not selected_item:
                messagebox.showerror("Error", "Please select a security to sell.")
                return
            sec_values = tree.item(selected_item[0], 'values')
            sec = next(s for s in portfolio if s.name == sec_values[0])

            try:
                amount = int(simpledialog.askstring("Amount", f"Enter amount to sell (Available: {sec.ammont}):"))
                if amount > sec.ammont:
                    messagebox.showerror("Error", "Not enough units to sell.")
                    return
            except (TypeError, ValueError):
                messagebox.showerror("Error", "Invalid amount.")
                return

            success, msg = self.controller.sell(sec.name, amount)

            messagebox.showinfo("Sell Result", msg)

        tk.Button(sell_window, text="Sell Selected Security", command=confirm_sell).pack(pady=10)

    def show_portfolio(self):
        portfolio_window = tk.Toplevel(self.master)
        portfolio_window.title("Current Portfolio")
        portfolio_window.geometry("700x400")

        portfolio = self.controller.get_portfolio_data()

        tree = ttk.Treeview(portfolio_window, columns=('Name', 'Amount', 'Basevalue', 'Sector', 'Subtype'), show='headings')
        tree.heading('Name', text='Name')
        tree.heading('Amount', text='Amount')
        tree.heading('Basevalue', text='Base Value')
        tree.heading('Sector', text='Sector')
        tree.heading('Subtype', text='Subtype')
        tree.pack(expand=True, fill='both')

        for sec in portfolio:
            tree.insert('', 'end', values=(sec.name, sec.ammont, sec.basevalue, sec.sector, sec.subtype))

    def show_graph(self):
        portfolio_data = self.controller.get_portfolio_data()
        display_portfolio_graph(portfolio_data)

if __name__ == "__main__":
    root = tk.Tk()
    app = PortfolioApp(root)
    root.mainloop()
