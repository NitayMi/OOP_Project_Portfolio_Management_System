import ollama
from abc import ABC, abstractmethod

class IAIAdvisor(ABC):
    @abstractmethod
    def get_advice(self, question: str) -> str:
        pass

class ollamamodel:   
    def __init__(self, model='deepseek-r1:7b'):
        self.model = model  # שמירה של המודל למקרה ונרצה להחליף

    def get_advice(self, question):
        try:
            response = ollama.generate(model=self.model, prompt=question)
            answer = response.get('response', '').strip()
            if not answer:
                return "❌ AI did not return a valid response. Please try again."
            return f"💡 AI Advisor: {answer}"
        except Exception as e:
            return f"❌ AI Error: {e}"

class OllamaAIAdvisor(IAIAdvisor):
    def __init__(self):
        self.ai = ollamamodel()

    def get_advice(self, question: str) -> str:
        return self.ai.get_advice(question)
    
# =============================================================================
from rag_engine import query as rag_query
import ollama


class AIAdvisorRAG:
    """
    AIAdvisorRAG uses both RAG (Retrieval-Augmented Generation) and AI (Ollama)
    to generate personalized investment advice based on the user's portfolio and external knowledge.
    """

    def __init__(self, model='deepseek-r1:7b'):
        """
        Initializes the AIAdvisorRAG instance.

        :param model: AI model to use (default: 'deepseek-r1:7b')
        """
        self.model = model

    def get_advice(self, question, portfolio_data=None):
        """
        Generate AI-based investment advice, using portfolio data and RAG knowledge.

        :param question: User's question to the AI.
        :param portfolio_data: Optional portfolio data to personalize the answer.
        :return: AI-generated advice string.
        """

        # Build portfolio context
        portfolio_context = ""
        if portfolio_data:
            portfolio_context = "\n".join([
                f"- {item.name}, {item.security_type}, Sector: {item.sector}, Risk: {item.variance}, Amount: {item.ammont}"
                for item in portfolio_data
            ])

        # Query background knowledge using RAG
        rag_context = rag_query(question, top_k=3)

        # Final question with context
        full_question = f"""
You are a professional investment advisor AI.

User's Risk Profile and Portfolio:
{portfolio_context}

Relevant Background Knowledge:
{rag_context}

Question:
{question}

Provide a professional and personalized investment recommendation.
"""

        # Generate AI response
        response = ollama.generate(
            model=self.model,
            prompt=full_question,
            system="You are a professional investment advisor AI. Answer clearly and professionally."  # Optional: can be removed if not needed
        )

        return response.get('response', '❌ No valid response')
