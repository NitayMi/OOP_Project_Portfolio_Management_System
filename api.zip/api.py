from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from controller import controller
import requests

app = FastAPI()

class TradeRequest(BaseModel):
    name: str
    sector: str
    security_type: str
    subtype: str
    amount: int
    variance: float = None
    basevalue: float = None


@app.get("/portfolio")
def get_portfolio():
    try:
        c = controller("Medium")
        portfolio = c.get_portfolio_data()
        return [vars(item) for item in portfolio]
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/risk")
def get_total_risk():
    try:
        c = controller("Medium")
        risk = c.get_total_risk()
        return {"total_risk": risk}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/buy")
def buy(trade: TradeRequest):
    try:
        c = controller("Medium")
        success, message = c.buy(trade.name, trade.sector, trade.variance, trade.security_type, trade.subtype, trade.amount, trade.basevalue)
        return {"success": success, "message": message}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.post("/sell")
def sell(trade: TradeRequest):
    try:
        c = controller("Medium")
        success, message = c.sell(trade.name, trade.security_type, trade.sector, trade.subtype, trade.amount)
        return {"success": success, "message": message}
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
    
@app.post("/stream")
async def stream_response(data: dict):
    prompt = data.get("prompt", "")

    async def fake_streamer():
        import time
        from advisor_ai import AdvisorAI

        ai = AdvisorAI()
        response = ai.ask_ai(prompt)

        # פיצול תשובה למילים
        for word in response.split():
            yield word + " "
            time.sleep(0.1)  # סימולציה של סטרים, אפשר להוריד ל-0.05 אם רוצה יותר מהר

    return StreamingResponse(fake_streamer(), media_type="text/plain")


def stream_chat_completion(prompt, on_update):
    url = "http://127.0.0.1:8000/v1/chat/completions"  # הכתובת של השרת שלך
    headers = {"Content-Type": "application/json"}

    payload = {
        "model": "local-model",  # תחליף בשם המודל שאתה מריץ, או תמחק אם לא צריך
        "messages": [{"role": "user", "content": prompt}],
        "stream": True
    }

    with requests.post(url, json=payload, headers=headers, stream=True) as response:
        if response.status_code != 200:
            print("Error:", response.text)
            return

        for line in response.iter_lines():
            if line:
                if line.startswith(b"data: "):
                    line = line.removeprefix(b"data: ").decode('utf-8')
                    on_update(line)  # שולח כל קטע טקסט לגואי בזמן אמת
