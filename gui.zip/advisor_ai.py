import requests
import tkinter as tk
from tkinter import scrolledtext
from datetime import datetime

# כתובת ה-API שלך
API_BASE_URL = "http://127.0.0.1:8000"
# כתובת ה-AI שלך (Ollama deepseek)
AI_API_URL = "http://127.0.0.1:11434/api/generate"

# שליפת תיק השקעות
def get_portfolio():
    response = requests.get(f"{API_BASE_URL}/portfolio")
    return response.json()

# שליפת סיכון כולל
def get_total_risk():
    response = requests.get(f"{API_BASE_URL}/risk")
    return response.json()

# שליחת שאלה ל-AI
def ask_ai(question, model="deepseek-r1:7b"):
    response = requests.post(
        AI_API_URL,
        json={
            "model": model,
            "prompt": question,
            "stream": False
        }
    )
    return response.json()

# שמירת תשובה לקובץ
def save_response_to_file(response):
    with open("ai_advisor_history.log", "a", encoding="utf-8") as file:
        file.write(f"\n[{datetime.now()}]\n{response}\n{'-'*50}\n")

# יצירת פופאפ לתצוגת תשובה
def show_ai_response(response):
    popup = tk.Toplevel()
    popup.title("AI Advisor Response")
    popup.geometry("600x400")

    text_area = scrolledtext.ScrolledText(popup, wrap=tk.WORD, width=70, height=20)
    text_area.insert(tk.INSERT, response)
    text_area.config(state=tk.DISABLED)
    text_area.pack(pady=10, padx=10)

    tk.Button(popup, text="Close", command=popup.destroy).pack(pady=5)

# הפונקציה הראשית - מחוברת ל-GUI
def run_ai_advisor():
    print("🔄 Fetching portfolio...")
    portfolio = get_portfolio()
    print("🔄 Fetching total risk...")
    risk = get_total_risk()

    if not portfolio or 'total_risk' not in risk:
        show_ai_response("❌ Error: Could not fetch portfolio or risk data.")
        return

    question = f"""
I have this portfolio: {portfolio}.
The total risk is {risk['total_risk']}.
Please summarize your response in bullet points (max 5 points) and limit it to 200 words.
"""
    
    print("🤖 Sending to AI for advice...\n")
    ai_response = ask_ai(question)

    response_text = ai_response.get("response", "❌ AI did not return a valid response.")
    show_ai_response(response_text)
    save_response_to_file(response_text)

import tkinter as tk
from tkinter import simpledialog, scrolledtext

# פונקציה לשאלה חופשית ל-AI
def ask_custom_question():
    # חלון קלט לשאלה
    root = tk.Tk()
    root.withdraw()  # להסתיר חלון ראשי

    user_question = simpledialog.askstring("Ask AI", "Enter your question for AI:")
    if not user_question:
        return  # אם לא הוזנה שאלה

    # שליחת השאלה ל-AI
    ai_response = ask_ai(user_question)
    response_text = ai_response.get("response", "❌ AI did not return a valid response.")

    # תצוגת התשובה
    popup = tk.Toplevel()
    popup.title("AI Response")
    popup.geometry("600x400")

    text_area = scrolledtext.ScrolledText(popup, wrap=tk.WORD, width=70, height=20)
    text_area.insert(tk.INSERT, response_text)
    text_area.config(state=tk.DISABLED)
    text_area.pack(pady=10, padx=10)

    tk.Button(popup, text="Close", command=popup.destroy).pack(pady=5)

    # שמירה לקובץ
    save_response_to_file(f"Q: {user_question}\nA: {response_text}")
