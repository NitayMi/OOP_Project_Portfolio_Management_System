from view import view

def main():
    screen= view()
    screen.show()



if __name__ == "__main__":
    main()



# לא לשכוח לבצע את כל ההתקנות שנדרשות לפני הרצת הקוד
# pip install -r requirements.txt